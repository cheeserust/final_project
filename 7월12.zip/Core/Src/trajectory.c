#include "../Inc/trajectory.h"
#include "../Inc/stepper.h"

#define STAGING_FREE      0u
#define STAGING_RECEIVING 1u
#define STAGING_COMPLETE  2u
#define ACK_EVENT_QUEUE_SIZE 16u

typedef struct {
    uint8_t state;
    uint8_t trajectory_id;
    uint8_t point_seq;
    uint8_t duration_5ms;
    uint8_t received_axis_mask;
    uint32_t start_ms;
    TrajectoryPoint point;
} TrajectoryStagingSlot;

typedef struct {
    TrajectoryPoint points[TRAJECTORY_POINT_RING_SIZE];
    volatile uint8_t head;
    volatile uint8_t tail;
} TrajectoryPointRingQueue;

#if BOARD_ID == BOARD_ID_BOARD1
static const int32_t gear_ratio[AXIS_COUNT] = {20, 50, 30, 20};
static const int32_t motor_steps_per_rev[AXIS_COUNT] = {200, 200, 200, 200};
static const int32_t min_angle[AXIS_COUNT] = {-8500, -7810, -9150, -9000};
static const int32_t max_angle[AXIS_COUNT] = {9000, 8000, 9000, 18000};
static const int32_t home_angle[AXIS_COUNT] = {-8650, -7810, -9150, -9000};
#else
static const int32_t gear_ratio[AXIS_COUNT] = {20};
static const int32_t motor_steps_per_rev[AXIS_COUNT] = {200};
static const int32_t min_angle[AXIS_COUNT] = {-9000};
static const int32_t max_angle[AXIS_COUNT] = {18000};
static const int32_t home_angle[AXIS_COUNT] = {-9000};
#endif

static TrajectoryStagingSlot g_staging[TRAJECTORY_STAGING_SLOT_COUNT];
static TrajectoryPointRingQueue g_point_queue;
static TrajectoryPoint g_current_point;
static uint32_t g_current_point_start_ms;
static uint8_t g_current_point_has_motion;
static TrajectoryAckEvent g_ack_events[ACK_EVENT_QUEUE_SIZE];
static uint8_t g_ack_head;
static uint8_t g_ack_tail;
static uint8_t g_reserved_point_count;
static uint8_t g_active_trajectory_valid;
static uint8_t g_active_trajectory_id;
static uint8_t g_cancelled_trajectory_valid;
static uint8_t g_cancelled_trajectory_id;
static uint8_t g_next_commit_seq;
static volatile uint8_t g_trajectory_started;
static volatile uint8_t g_queue_overflow_clear_request;
static volatile uint8_t g_queue_overflow_clear_ack;
static volatile int32_t g_planned_step[AXIS_COUNT];

static void clear_point(TrajectoryPoint *point)
{
    point->duration_ms = 0;
    for (uint8_t i = 0; i < AXIS_COUNT; i++) {
        point->target_step[i] = 0;
        point->speed[i] = 0;
    }
}

static void clear_slot(TrajectoryStagingSlot *slot)
{
    slot->state = STAGING_FREE;
    slot->trajectory_id = 0;
    slot->point_seq = 0;
    slot->duration_5ms = 0;
    slot->received_axis_mask = 0;
    slot->start_ms = 0;
    clear_point(&slot->point);
}

static uint8_t queue_used_count(void)
{
    uint8_t head = g_point_queue.head;
    uint8_t tail = g_point_queue.tail;
    if (tail >= head) return (uint8_t)(tail - head);
    return (uint8_t)(TRAJECTORY_POINT_RING_SIZE - head + tail);
}

static uint8_t queue_physical_free_count(void)
{
    return (uint8_t)(TRAJECTORY_POINT_QUEUE_SIZE - queue_used_count());
}

static uint8_t queue_push(const TrajectoryPoint *point)
{
    uint8_t tail = g_point_queue.tail;
    uint8_t next_tail = (uint8_t)((tail + 1u) % TRAJECTORY_POINT_RING_SIZE);
    if (next_tail == g_point_queue.head) return 0;
    g_point_queue.points[tail] = *point;
    __DMB();
    g_point_queue.tail = next_tail;
    return 1;
}

static uint8_t queue_pop(TrajectoryPoint *point)
{
    uint8_t head = g_point_queue.head;
    if (head == g_point_queue.tail) return 0;
    *point = g_point_queue.points[head];
    __DMB();
    g_point_queue.head = (uint8_t)((head + 1u) % TRAJECTORY_POINT_RING_SIZE);
    return 1;
}

static void ack_event_push(uint8_t result, uint8_t trajectory_id,
                           uint8_t point_seq, uint8_t mask)
{
    uint8_t next = (uint8_t)((g_ack_tail + 1u) % ACK_EVENT_QUEUE_SIZE);
    if (next == g_ack_head) return;
    g_ack_events[g_ack_tail].result = result;
    g_ack_events[g_ack_tail].trajectory_id = trajectory_id;
    g_ack_events[g_ack_tail].point_seq = point_seq;
    g_ack_events[g_ack_tail].received_axis_mask = mask;
    __DMB();
    g_ack_tail = next;
}

uint8_t trajectory_take_ack_event(TrajectoryAckEvent *event)
{
    uint8_t head = g_ack_head;
    if (event == 0 || head == g_ack_tail) return 0;
    *event = g_ack_events[head];
    __DMB();
    g_ack_head = (uint8_t)((head + 1u) % ACK_EVENT_QUEUE_SIZE);
    return 1;
}

static TrajectoryStagingSlot *find_slot(uint8_t trajectory_id, uint8_t point_seq)
{
    for (uint8_t i = 0; i < TRAJECTORY_STAGING_SLOT_COUNT; i++) {
        if (g_staging[i].state != STAGING_FREE &&
            g_staging[i].trajectory_id == trajectory_id &&
            g_staging[i].point_seq == point_seq) return &g_staging[i];
    }
    return 0;
}

static TrajectoryStagingSlot *find_free_slot(void)
{
    for (uint8_t i = 0; i < TRAJECTORY_STAGING_SLOT_COUNT; i++) {
        if (g_staging[i].state == STAGING_FREE) return &g_staging[i];
    }
    return 0;
}

static void flush_completed_in_order(void)
{
    while (1) {
        TrajectoryStagingSlot *slot = find_slot(g_active_trajectory_id, g_next_commit_seq);
        if (slot == 0 || slot->state != STAGING_COMPLETE) return;
        if (!queue_push(&slot->point)) return;

        for (uint8_t axis = 0; axis < AXIS_COUNT; axis++) {
            g_planned_step[axis] = slot->point.target_step[axis];
        }
        ack_event_push(TRAJECTORY_ACK_COMMITTED, slot->trajectory_id,
                       slot->point_seq, slot->received_axis_mask);
        if (g_reserved_point_count > 0) g_reserved_point_count--;
        clear_slot(slot);
        g_next_commit_seq++;
    }
}

void trajectory_cancel_staging(void)
{
    for (uint8_t i = 0; i < TRAJECTORY_STAGING_SLOT_COUNT; i++) clear_slot(&g_staging[i]);
    g_reserved_point_count = 0;
}

void trajectory_stop_motion(void)
{
    g_motion_active = 0;
    stepper_cancel_motion();
    for (uint8_t i = 0; i < AXIS_COUNT; i++) {
        g_target_step[i] = g_current_step[i];
        g_motion_start_step[i] = g_current_step[i];
    }
}

void trajectory_sync_planned_to_current(void)
{
    for (uint8_t i = 0; i < AXIS_COUNT; i++) g_planned_step[i] = g_current_step[i];
}

int32_t trajectory_get_planned_step(uint8_t axis_id)
{
    return axis_id < AXIS_COUNT ? g_planned_step[axis_id] : 0;
}

void trajectory_clear(void)
{
    g_point_queue.head = 0;
    g_point_queue.tail = 0;
    g_ack_head = 0;
    g_ack_tail = 0;
    trajectory_cancel_staging();
    trajectory_stop_motion();
    trajectory_sync_planned_to_current();
    g_active_trajectory_valid = 0;
    g_active_trajectory_id = 0;
    g_next_commit_seq = 0;
    g_trajectory_started = 0;
}

uint8_t trajectory_start(uint8_t trajectory_id)
{
    if (!g_active_trajectory_valid || trajectory_id != g_active_trajectory_id) return 0;
    g_trajectory_started = 1;
    return 1;
}

uint8_t trajectory_cancel(uint8_t trajectory_id)
{
    if (g_active_trajectory_valid && trajectory_id != g_active_trajectory_id) return 0;
    trajectory_clear();
    g_cancelled_trajectory_id = trajectory_id;
    g_cancelled_trajectory_valid = 1;
    if (g_enabled && !ESTOP_ACTIVE() && g_error_code == ERR_NONE) g_state = STATE_IDLE;
    return 1;
}

void trajectory_request_queue_overflow_clear(void)
{
    g_queue_overflow_clear_ack = 0;
    g_queue_overflow_clear_request = 1;
}

void trajectory_cancel_queue_overflow_clear(void)
{
    g_queue_overflow_clear_request = 0;
    g_queue_overflow_clear_ack = 0;
}

uint8_t trajectory_take_queue_overflow_clear_ack(void)
{
    if (!g_queue_overflow_clear_ack) return 0;
    g_queue_overflow_clear_ack = 0;
    return 1;
}

static void service_queue_overflow_clear_request(void)
{
    if (!g_queue_overflow_clear_request || !g_queue_overflow) return;
    g_queue_overflow = 0;
    g_queue_overflow_clear_request = 0;
    g_queue_overflow_clear_ack = 1;
}

uint8_t get_free_trajectory_point_count(void)
{
    uint8_t free_points = queue_physical_free_count();
    return free_points > g_reserved_point_count ?
           (uint8_t)(free_points - g_reserved_point_count) : 0;
}

int32_t angle_to_step(uint8_t axis_id, int32_t angle_raw)
{
    int64_t value;
    if (axis_id >= AXIS_COUNT) return 0;
    value = (int64_t)angle_raw * gear_ratio[axis_id] *
            motor_steps_per_rev[axis_id] * MICROSTEP;
    return (int32_t)(value / 36000);
}

int32_t step_to_angle(uint8_t axis_id, int32_t step)
{
    int64_t value;
    int64_t steps_per_rev;
    if (axis_id >= AXIS_COUNT) return 0;
    value = (int64_t)step * 36000;
    steps_per_rev = (int64_t)gear_ratio[axis_id] *
                    motor_steps_per_rev[axis_id] * MICROSTEP;
    value += value >= 0 ? steps_per_rev / 2 : -(steps_per_rev / 2);
    return (int32_t)(value / steps_per_rev);
}

int32_t get_home_angle(uint8_t axis_id)
{
    return axis_id < AXIS_COUNT ? home_angle[axis_id] : 0;
}

uint8_t trajectory_resolve_target_step(uint8_t axis_id, int32_t target_raw,
                                       uint8_t relative, uint8_t step_mode,
                                       int32_t *target_step)
{
    int64_t resolved;
    int32_t min_step;
    int32_t max_step;
    if (axis_id >= AXIS_COUNT || target_step == 0) return 0;
    resolved = step_mode ? target_raw : angle_to_step(axis_id, target_raw);
    if (relative) resolved += g_planned_step[axis_id];
    if (resolved < INT32_MIN || resolved > INT32_MAX) return 0;
    *target_step = (int32_t)resolved;
    min_step = angle_to_step(axis_id, min_angle[axis_id]);
    max_step = angle_to_step(axis_id, max_angle[axis_id]);
    if (min_step > max_step) {
        int32_t swap = min_step;
        min_step = max_step;
        max_step = swap;
    }
    return (*target_step >= min_step && *target_step <= max_step) ? 1u : 0u;
}

uint8_t trajectory_handle_staging_timeout(void)
{
    uint8_t timed_out = 0;
    for (uint8_t i = 0; i < TRAJECTORY_STAGING_SLOT_COUNT; i++) {
        TrajectoryStagingSlot *slot = &g_staging[i];
        if (slot->state == STAGING_FREE) continue;
        if ((global_tick_ms - slot->start_ms) <= STAGING_TIMEOUT_MS) continue;
        ack_event_push(TRAJECTORY_ACK_STAGING_TIMEOUT, slot->trajectory_id,
                       slot->point_seq, slot->received_axis_mask);
        if (g_reserved_point_count > 0) g_reserved_point_count--;
        clear_slot(slot);
        timed_out = 1;
    }
    return timed_out;
}

static uint16_t duration_to_ms(uint8_t duration_5ms)
{
    uint16_t ms = (uint16_t)duration_5ms * 5u;
    return ms == 0 ? 1u : ms;
}

uint8_t trajectory_add_axis_command(uint8_t motor_id, int32_t target_step,
                                    uint8_t trajectory_id, uint8_t point_seq,
                                    uint8_t duration_5ms,
                                    uint8_t *received_axis_mask)
{
    TrajectoryStagingSlot *slot;
    uint8_t motor_bit;
    uint8_t sequence_distance;

    if (received_axis_mask != 0) *received_axis_mask = 0;
    if (motor_id >= AXIS_COUNT || duration_5ms == 0) return TRAJECTORY_STAGING_INVALID;

    if (!g_active_trajectory_valid) {
        if (g_cancelled_trajectory_valid && trajectory_id == g_cancelled_trajectory_id) {
            return TRAJECTORY_STAGING_INVALID;
        }
        g_active_trajectory_valid = 1;
        g_active_trajectory_id = trajectory_id;
        g_next_commit_seq = point_seq;
    }
    if (trajectory_id != g_active_trajectory_id) return TRAJECTORY_STAGING_INVALID;

    sequence_distance = (uint8_t)(point_seq - g_next_commit_seq);
    if (sequence_distance >= 128u) {
        if (received_axis_mask != 0) *received_axis_mask = (uint8_t)((1u << AXIS_COUNT) - 1u);
        return TRAJECTORY_STAGING_DUPLICATE;
    }
    if (sequence_distance >= TRAJECTORY_STAGING_SLOT_COUNT) return TRAJECTORY_STAGING_WINDOW_FULL;

    slot = find_slot(trajectory_id, point_seq);
    if (slot == 0) {
        if (get_free_trajectory_point_count() == 0) return TRAJECTORY_STAGING_QUEUE_FULL;
        slot = find_free_slot();
        if (slot == 0) return TRAJECTORY_STAGING_WINDOW_FULL;
        clear_slot(slot);
        slot->state = STAGING_RECEIVING;
        slot->trajectory_id = trajectory_id;
        slot->point_seq = point_seq;
        slot->duration_5ms = duration_5ms;
        slot->start_ms = global_tick_ms;
        slot->point.duration_ms = duration_to_ms(duration_5ms);
        g_reserved_point_count++;
    } else if (slot->duration_5ms != duration_5ms) {
        if (g_reserved_point_count > 0) g_reserved_point_count--;
        clear_slot(slot);
        return TRAJECTORY_STAGING_INVALID;
    }

    motor_bit = (uint8_t)(1u << motor_id);
    if (slot->received_axis_mask & motor_bit) {
        if (received_axis_mask != 0) *received_axis_mask = slot->received_axis_mask;
        if (slot->point.target_step[motor_id] == target_step) {
            return TRAJECTORY_STAGING_DUPLICATE;
        }
        if (g_reserved_point_count > 0) g_reserved_point_count--;
        clear_slot(slot);
        return TRAJECTORY_STAGING_INVALID;
    }

    slot->point.target_step[motor_id] = target_step;
    slot->received_axis_mask |= motor_bit;
    if (received_axis_mask != 0) *received_axis_mask = slot->received_axis_mask;

    if (slot->received_axis_mask != (uint8_t)((1u << AXIS_COUNT) - 1u)) {
        return TRAJECTORY_STAGING_WAITING;
    }

    slot->state = STAGING_COMPLETE;
    if (slot->point_seq != g_next_commit_seq) {
        ack_event_push(TRAJECTORY_ACK_BUFFERED_OUT_OF_ORDER, trajectory_id,
                       point_seq, slot->received_axis_mask);
        return TRAJECTORY_STAGING_BUFFERED;
    }

    flush_completed_in_order();
    return TRAJECTORY_STAGING_COMMITTED;
}

static void calculate_lookahead_stop(int32_t stop_step[AXIS_COUNT])
{
    uint8_t head = g_point_queue.head;
    uint8_t tail = g_point_queue.tail;
    for (uint8_t axis = 0; axis < AXIS_COUNT; axis++) {
        int32_t previous = g_current_step[axis];
        int32_t stop = g_current_point.target_step[axis];
        int8_t direction = stop > previous ? 1 : (stop < previous ? -1 : 0);
        uint8_t index = head;
        previous = stop;
        while (index != tail && direction != 0) {
            int32_t next = g_point_queue.points[index].target_step[axis];
            int8_t next_direction = next > previous ? 1 : (next < previous ? -1 : 0);
            if (next_direction != 0 && next_direction != direction) break;
            stop = next;
            previous = next;
            index = (uint8_t)((index + 1u) % TRAJECTORY_POINT_RING_SIZE);
        }
        stop_step[axis] = stop;
    }
}

static void start_point(const TrajectoryPoint *point)
{
    int32_t stop_step[AXIS_COUNT];
    g_current_point = *point;
    g_current_point_start_ms = global_tick_ms;
    g_current_point_has_motion = 0;
    for (uint8_t i = 0; i < AXIS_COUNT; i++) {
        g_motion_start_step[i] = g_current_step[i];
        g_target_step[i] = point->target_step[i];
        if (g_target_step[i] != g_current_step[i]) g_current_point_has_motion = 1;
    }
    calculate_lookahead_stop(stop_step);
    stepper_prepare_motion(point->duration_ms == 0 ? 1 : point->duration_ms, stop_step);
    g_motion_active = 1;
    g_state = STATE_MOVING;
}

void trajectory_1ms_interrupt(void)
{
    TrajectoryPoint point;
    uint8_t reached = 1;

    service_queue_overflow_clear_request();
    if (!g_enabled || ESTOP_ACTIVE() || g_error_code != ERR_NONE ||
        g_homing_active || !system_all_homed()) {
        if (g_motion_active) trajectory_stop_motion();
        return;
    }

    if (!g_trajectory_started) return;

    if (!g_motion_active) {
        if (queue_pop(&point)) start_point(&point);
        else if (g_state == STATE_MOVING) g_state = STATE_IDLE;
    }
    if (!g_motion_active) return;

    {
        int32_t stop_step[AXIS_COUNT];
        calculate_lookahead_stop(stop_step);
        stepper_update_stop_steps(stop_step);
    }

    for (uint8_t i = 0; i < AXIS_COUNT; i++) {
        if (g_current_step[i] != g_current_point.target_step[i]) {
            reached = 0;
            break;
        }
    }
    if (!g_current_point_has_motion &&
        (global_tick_ms - g_current_point_start_ms) < g_current_point.duration_ms) {
        return;
    }
    if (!reached) return;

    if (queue_pop(&point)) {
        /* Normal point handoff deliberately preserves DDA phase/feed. */
        start_point(&point);
    } else {
        g_motion_active = 0;
        stepper_cancel_motion();
        g_state = STATE_IDLE;
    }
}
