#include "../Inc/board_can.h"
#include "../Inc/gpio.h"
#include "../Inc/stepper.h"
#include "../Inc/trajectory.h"

static volatile uint8_t g_status_event;
static uint8_t g_status_sequence_counter;
static CanFrame g_pending_status_frame;
static CanFrame g_pending_position_frame;
static uint8_t g_status_tx_pending;
static uint8_t g_position_tx_pending;
static uint32_t g_next_tx_retry_ms;
#define CAN_ACK_TX_QUEUE_SIZE 16u
static CanFrame g_ack_tx_queue[CAN_ACK_TX_QUEUE_SIZE];
static uint8_t g_ack_tx_head;
static uint8_t g_ack_tx_tail;
static uint8_t g_ack_sequence;

static int32_t read_i32_le(const uint8_t *p)
{
    uint32_t v = ((uint32_t)p[0]) |
                 ((uint32_t)p[1] << 8) |
                 ((uint32_t)p[2] << 16) |
                 ((uint32_t)p[3] << 24);
    return (int32_t)v;
}

static void write_i16_le(uint8_t *p, int16_t value)
{
    uint16_t v = (uint16_t)value;
    p[0] = (uint8_t)(v & 0xFF);
    p[1] = (uint8_t)((v >> 8) & 0xFF);
}

static int16_t clamp_i16(int32_t value)
{
    if (value > 32767) return 32767;
    if (value < -32768) return -32768;
    return (int16_t)value;
}

static uint8_t make_position_flags(uint8_t motor_id,
                                   uint8_t state_snapshot,
                                   uint8_t error_snapshot,
                                   uint8_t enabled_snapshot,
                                   uint8_t homing_done_snapshot,
                                   uint8_t homing_active_snapshot,
                                   uint8_t motion_active_snapshot,
                                   const int32_t current_step_snapshot[AXIS_COUNT],
                                   const int32_t target_step_snapshot[AXIS_COUNT]);

static uint8_t frame_is_exact_8_bytes(const CanFrame *frame)
{
    return (frame != 0 && frame->dlc == 8) ? 1 : 0;
}

static uint8_t reserved_zero(const CanFrame *frame, uint8_t start_index)
{
    for (uint8_t i = start_index; i < 8; i++) {
        if (frame->data[i] != 0) return 0;
    }
    return 1;
}

void board_can_request_status_event(void)
{
    g_status_event = 1;
}

static void enter_error(uint8_t error_code)
{
    trajectory_clear();
    trajectory_cancel_queue_overflow_clear();
    g_queue_overflow = 0;
    g_error_code = error_code;
    if (!ESTOP_ACTIVE()) g_state = STATE_ERROR;
    board_can_request_status_event();
}

static uint8_t motion_command_allowed(void)
{
    if (!g_enabled) return 0;
    if (ESTOP_ACTIVE()) return 0;
    if (g_error_code != ERR_NONE) return 0;
    if (g_homing_active) return 0;
    if (!system_all_homed()) return 0;
    return 1;
}

static void queue_ack(uint8_t result, uint8_t trajectory_id,
                      uint8_t point_seq, uint8_t received_axis_mask)
{
    uint8_t next = (uint8_t)((g_ack_tx_tail + 1u) % CAN_ACK_TX_QUEUE_SIZE);
    CanFrame *frame;
    if (next == g_ack_tx_head) return;
    frame = &g_ack_tx_queue[g_ack_tx_tail];
    frame->id = BOARD_ACK_CAN_ID;
    frame->dlc = 8;
    frame->data[0] = 2;
    frame->data[1] = result;
    frame->data[2] = trajectory_id;
    frame->data[3] = point_seq;
    frame->data[4] = received_axis_mask;
    frame->data[5] = get_free_trajectory_point_count();
    frame->data[6] = mcp2515_rx_overflow_count();
    frame->data[7] = g_ack_sequence++;
    __DMB();
    g_ack_tx_tail = next;
}

void board_can_drain_trajectory_events(void)
{
    TrajectoryAckEvent event;
    while (trajectory_take_ack_event(&event)) {
        queue_ack(event.result, event.trajectory_id, event.point_seq,
                  event.received_axis_mask);
    }
}

static void handle_estop(const CanFrame *frame)
{
#if ENABLE_ESTOP_LOGIC
    if (!frame_is_exact_8_bytes(frame) || frame->data[0] != 1 || !reserved_zero(frame, 1)) {
        enter_error(ERR_INVALID_CMD);
        return;
    }

    g_estop = 1;
    g_enabled = 0;
    g_error_code = ERR_NONE;
    trajectory_cancel_queue_overflow_clear();
    g_queue_overflow = 0;
    g_homing_active = 0;
    g_state = STATE_ESTOP;
    trajectory_clear();
    stepper_stop_all();
    motor_disable();
    board_can_request_status_event();
#else
    (void)frame;
#endif
}

static void handle_enable_disable(const CanFrame *frame)
{
    if (!frame_is_exact_8_bytes(frame) || !reserved_zero(frame, 1)) {
        enter_error(ERR_INVALID_CMD);
        return;
    }

    if (frame->data[0] == 1) {
        if (g_error_code != ERR_NONE || g_state == STATE_ERROR || g_state == STATE_ESTOP) {
            trajectory_clear();
        }
        g_estop = 0;
        g_error_code = ERR_NONE;
        g_enabled = 1;
        motor_enable();
        if (g_state == STATE_ESTOP || g_state == STATE_ERROR ||
            g_state == STATE_INIT || g_state == STATE_DISABLED) {
            g_state = STATE_IDLE;
        }
    } else if (frame->data[0] == 0) {
        trajectory_clear();
        stepper_stop_all();
        g_homing_active = 0;
        g_enabled = 0;
        motor_disable();
        g_state = STATE_DISABLED;
    } else {
        enter_error(ERR_INVALID_CMD);
        return;
    }

    board_can_request_status_event();
}

static void handle_arm_homing(const CanFrame *frame)
{
    if (!frame_is_exact_8_bytes(frame) || frame->data[0] != HOMING_ALL_AXIS ||
        frame->data[1] != 0 || !reserved_zero(frame, 2)) {
        enter_error(ERR_INVALID_CMD);
        return;
    }

    if (g_queue_overflow) {
        board_can_request_status_event();
        return;
    }

    if (!g_enabled || ESTOP_ACTIVE() || g_error_code != ERR_NONE) {
        enter_error(ERR_INVALID_CMD);
        return;
    }

    g_error_code = ERR_NONE;
    trajectory_clear();
    stepper_stop_all();
    stepper_start_homing_all();
    board_can_request_status_event();
}

static void handle_clear_error(const CanFrame *frame)
{
    if (!frame_is_exact_8_bytes(frame) || frame->data[0] != HOMING_ALL_AXIS ||
        !reserved_zero(frame, 1)) {
        enter_error(ERR_INVALID_CMD);
        return;
    }

    if (g_queue_overflow && g_error_code == ERR_NONE) {
        trajectory_request_queue_overflow_clear();
        board_can_request_status_event();
        return;
    } else {
        g_error_code = ERR_NONE;
        trajectory_cancel_queue_overflow_clear();
        g_queue_overflow = 0;
        trajectory_clear();
    }
    if (!ESTOP_ACTIVE()) {
        g_state = g_enabled ? STATE_IDLE : STATE_DISABLED;
    }
    board_can_request_status_event();
}

static void handle_board_move(const CanFrame *frame)
{
    uint8_t b0;
    uint8_t motor_id;
    uint8_t execute;
    uint8_t relative;
    uint8_t step_mode;
    uint8_t duration_5ms;
    int32_t target_raw;
    int32_t target_step;
    uint8_t trajectory_id;
    uint8_t point_seq;
    uint8_t received_axis_mask = 0;
    uint8_t result;

    if (!frame_is_exact_8_bytes(frame)) {
        queue_ack(TRAJECTORY_ACK_INVALID, 0, 0, 0);
        return;
    }

    b0 = frame->data[0];
    execute = (b0 & CAN_CTRL_EXECUTE) ? 1 : 0;
    relative = (b0 & CAN_CTRL_RELATIVE) ? 1 : 0;
    step_mode = (b0 & CAN_CTRL_STEP_MODE) ? 1 : 0;
    motor_id = b0 & CAN_CTRL_MOTOR_MASK;

    trajectory_id = frame->data[5];
    point_seq = frame->data[6];
    duration_5ms = frame->data[7];

    if (!motion_command_allowed() || !execute || !(b0 & CAN_CTRL_PROTOCOL_V2) ||
        relative || motor_id >= AXIS_COUNT || duration_5ms == 0) {
        queue_ack(TRAJECTORY_ACK_INVALID, trajectory_id, point_seq, 0);
        return;
    }

    target_raw = read_i32_le(&frame->data[1]);

    if (!trajectory_resolve_target_step(motor_id, target_raw, relative, step_mode, &target_step)) {
        queue_ack(TRAJECTORY_ACK_INVALID, trajectory_id, point_seq, 0);
        return;
    }

    result = trajectory_add_axis_command(motor_id, target_step, trajectory_id,
                                         point_seq, duration_5ms,
                                         &received_axis_mask);
    if (result == TRAJECTORY_STAGING_INVALID) {
        queue_ack(TRAJECTORY_ACK_GROUP_CONFLICT, trajectory_id, point_seq,
                  received_axis_mask);
        return;
    }
    if (result == TRAJECTORY_STAGING_QUEUE_FULL) {
        queue_ack(TRAJECTORY_ACK_QUEUE_FULL, trajectory_id, point_seq,
                  received_axis_mask);
        return;
    }
    if (result == TRAJECTORY_STAGING_WINDOW_FULL) {
        queue_ack(TRAJECTORY_ACK_WINDOW_FULL, trajectory_id, point_seq,
                  received_axis_mask);
        return;
    }
    if (result == TRAJECTORY_STAGING_DUPLICATE) {
        queue_ack(TRAJECTORY_ACK_DUPLICATE, trajectory_id, point_seq,
                  received_axis_mask);
    }
    board_can_drain_trajectory_events();
    if (result == TRAJECTORY_STAGING_COMMITTED) board_can_request_status_event();
}

static void handle_trajectory_control(const CanFrame *frame)
{
    uint8_t ok = 0;
    if (!frame_is_exact_8_bytes(frame) || !reserved_zero(frame, 2)) {
        queue_ack(TRAJECTORY_ACK_INVALID, frame ? frame->data[1] : 0, 0, 0);
        return;
    }
    if (frame->data[0] == TRAJECTORY_CONTROL_START) {
        ok = trajectory_start(frame->data[1]);
    } else if (frame->data[0] == TRAJECTORY_CONTROL_CANCEL) {
        ok = trajectory_cancel(frame->data[1]);
    }
    if (!ok) {
        queue_ack(TRAJECTORY_ACK_INVALID, frame->data[1], 0, 0);
        return;
    }
    queue_ack(TRAJECTORY_ACK_COMMITTED, frame->data[1], 0xFFu, 0);
    board_can_request_status_event();
}

void board_can_handle_frame(const CanFrame *frame)
{
    if (frame == 0) return;

    switch (frame->id) {
    case CAN_ID_ESTOP:
        handle_estop(frame);
        break;
    case CAN_ID_ENABLE:
        handle_enable_disable(frame);
        break;
    case CAN_ID_HOMING:
        handle_arm_homing(frame);
        break;
    case CAN_ID_CLEAR_ERROR:
        handle_clear_error(frame);
        break;
    case BOARD_MOVE_CAN_ID:
        handle_board_move(frame);
        break;
    case CAN_ID_TRAJECTORY_CONTROL:
        handle_trajectory_control(frame);
        break;
    default:
        break;
    }
}

void board_can_queue_status(void)
{
    CanFrame frame;
    int32_t current_snapshot[AXIS_COUNT];
    int32_t target_snapshot[AXIS_COUNT];
    uint8_t state_snapshot;
    uint8_t fatal_error_snapshot;
    uint8_t reported_error_snapshot;
    uint8_t enabled_snapshot;
    uint8_t homing_done_snapshot;
    uint8_t homing_active_snapshot;
    uint8_t motion_active_snapshot;
    uint8_t axis_flags[4] = {0, 0, 0, 0};

    frame.id = BOARD_STATUS_CAN_ID;
    frame.dlc = 8;

    for (uint8_t i = 0; i < AXIS_COUNT; i++) {
        current_snapshot[i] = g_current_step[i];
        target_snapshot[i] = g_target_step[i];
    }
    state_snapshot = g_state;
    fatal_error_snapshot = g_error_code;
    reported_error_snapshot = system_reported_error_code();
    enabled_snapshot = g_enabled;
    homing_done_snapshot = g_homing_done_bits;
    homing_active_snapshot = g_homing_active;
    motion_active_snapshot = g_motion_active;

    for (uint8_t i = 0; i < AXIS_COUNT && i < 4; i++) {
        axis_flags[i] = make_position_flags(i,
                                            state_snapshot,
                                            fatal_error_snapshot,
                                            enabled_snapshot,
                                            homing_done_snapshot,
                                            homing_active_snapshot,
                                            motion_active_snapshot,
                                            current_snapshot,
                                            target_snapshot) & 0x0F;
    }

    frame.data[0] = state_snapshot;
    frame.data[1] = reported_error_snapshot;
    frame.data[2] = (uint8_t)(axis_flags[0] | (uint8_t)(axis_flags[1] << 4));
    frame.data[3] = (uint8_t)(axis_flags[2] | (uint8_t)(axis_flags[3] << 4));
    frame.data[4] = stepper_limit_switch_status_bits();
    frame.data[5] = get_free_trajectory_point_count();
    frame.data[6] = system_enabled_status();
    frame.data[7] = g_status_sequence_counter;

    g_pending_status_frame = frame;
    g_status_tx_pending = 1;
}

static uint8_t make_position_flags(uint8_t motor_id,
                                   uint8_t state_snapshot,
                                   uint8_t error_snapshot,
                                   uint8_t enabled_snapshot,
                                   uint8_t homing_done_snapshot,
                                   uint8_t homing_active_snapshot,
                                   uint8_t motion_active_snapshot,
                                   const int32_t current_step_snapshot[AXIS_COUNT],
                                   const int32_t target_step_snapshot[AXIS_COUNT])
{
    uint8_t flags = 0;
    uint8_t homed = (homing_done_snapshot & (uint8_t)(1 << motor_id)) ? 1 : 0;
    uint8_t moving = 0;

    if (homing_active_snapshot && !homed) moving = 1;
    if (motion_active_snapshot &&
        current_step_snapshot[motor_id] != target_step_snapshot[motor_id]) {
        moving = 1;
    }

    if (homed) flags |= 0x01;
    if (homed && enabled_snapshot && (!ENABLE_ESTOP_LOGIC || state_snapshot != STATE_ESTOP) &&
        state_snapshot != STATE_ERROR && error_snapshot == ERR_NONE) {
        flags |= 0x02;
    }
    if (moving) flags |= 0x04;
    if (homed && !moving && !homing_active_snapshot &&
        current_step_snapshot[motor_id] == target_step_snapshot[motor_id]) {
        flags |= 0x08;
    }

    return flags;
}

void board_can_queue_position_feedback_all(void)
{
    int32_t current_snapshot[AXIS_COUNT];
    CanFrame frame;

    for (uint8_t i = 0; i < AXIS_COUNT; i++) {
        current_snapshot[i] = g_current_step[i];
    }

    frame.id = BOARD_POSITION_CAN_ID;
    frame.dlc = 8;
    for (uint8_t i = 0; i < 8; i++) {
        frame.data[i] = 0;
    }
    for (uint8_t i = 0; i < AXIS_COUNT && i < 4; i++) {
        write_i16_le(&frame.data[i * 2], clamp_i16(step_to_angle(i, current_snapshot[i])));
    }

    g_pending_position_frame = frame;
    g_position_tx_pending = 1;
}

void board_can_service_tx(void)
{
    Mcp2515SendResult result;

    if ((int32_t)(global_tick_ms - g_next_tx_retry_ms) < 0) return;

    if (g_ack_tx_head != g_ack_tx_tail) {
        result = mcp2515_send_frame(&g_ack_tx_queue[g_ack_tx_head]);
        if (result == MCP2515_SEND_OK) {
            g_ack_tx_head = (uint8_t)((g_ack_tx_head + 1u) % CAN_ACK_TX_QUEUE_SIZE);
        } else {
            g_next_tx_retry_ms = global_tick_ms + 1;
            return;
        }
    }

    if (g_status_tx_pending) {
        result = mcp2515_send_frame(&g_pending_status_frame);
        if (result == MCP2515_SEND_OK) {
            g_status_tx_pending = 0;
            g_status_sequence_counter++;
        } else {
            g_next_tx_retry_ms = global_tick_ms + 1;
            return;
        }
    }

    if (g_position_tx_pending) {
        result = mcp2515_send_frame(&g_pending_position_frame);
        if (result == MCP2515_SEND_OK) {
            g_position_tx_pending = 0;
        } else {
            g_next_tx_retry_ms = global_tick_ms + 1;
        }
    }
}

void board_can_flush_status_event(void)
{
    if (!g_status_event) return;

    g_status_event = 0;
    board_can_queue_status();
}
