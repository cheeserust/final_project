# 서버 저장소 담당 GPT에게 그대로 전달할 프롬프트

당신은 ROS2/MoveIt2 중앙 서버와 Raspberry Pi SocketCAN 송신 코드를 수정하는 담당자다. 아래 CAN V2 계약은 이미 구현된 Board1 STM32 및 Arduino Board2 펌웨어의 실제 동작이다. 필드 의미, 단위, 큐 크기, 재전송 정책을 임의로 바꾸거나 추측하지 마라.

## 1. 작업 시작 전 필수 조사와 변경 제한

먼저 저장소 전체를 읽고 다음 실제 구현 위치를 찾아 목록으로 보고한 다음 수정하라.

1. `JointTrajectory` 또는 목표 관절값을 받는 ROS2 callback/action/service
2. trajectory point를 CAN frame으로 만드는 함수
3. global joint index와 joint name, board/local motor ID 매핑
4. SocketCAN socket을 소유하고 실제 `send()`/`sendmsg()`를 호출하는 코드
5. CAN 송신 큐, 송신 worker, timer callback, retry 로직
6. Board1/Board2/Board3 command packer와 공용 `pack_position_command()`
7. `0x201/0x202` Status 및 `0x301/0x302` Position parser
8. Queue Free, moving, target reached, homed, enabled, error 상태 저장 위치
9. trajectory duration 기반 timeout과 상위 task/action timeout
10. `arm_task_server_node.py`의 `duration + grace` 취소 로직
11. `send_test_trajectory`와 current→target→current 테스트 생성 로직
12. `roscue_arm_pick` 설정 검증기와 기존 duration tick 파라미터
13. 관련 unit/integration/virtual-CAN 테스트

저장소가 dirty하면 먼저 `git status`, 현재 diff 통계와 수정 파일을 보고하라. 사용자 소유 변경을 되돌리거나 덮어쓰지 마라. 관련 없는 리팩터링, 파일 이동, 이름 변경, formatting 전면 적용은 금지한다.

Board3 `0x103/0x203/0x303` 동작은 절대 변경하지 마라. 공용 packer를 직접 V2로 바꾸지 말고 Board1/Board2 V2 전용 API를 분리하라. Board3의 기존 payload snapshot 테스트를 반드시 유지한다.

## 2. 실제 축 매핑

global joint 배열 순서만 믿지 말고 joint name을 기준으로 명시적으로 매핑한다.

| Global joint | Joint name | Board | Move ID | Local motor ID |
|---:|---|---:|---:|---:|
| 0 | `base_joint` | 1 | `0x101` | 3 |
| 1 | `arm_joint_1` | 1 | `0x101` | 0 |
| 2 | `arm_joint_2` | 1 | `0x101` | 1 |
| 3 | `arm_joint_3` | 1 | `0x101` | 2 |
| 4 | `arm_joint_4` | 2 | `0x102` | 0 |

Board1 frame 송신 순서는 global joint 순서가 아니라 반드시 local motor `0,1,2,3`이다.

```text
arm_joint_1 -> Board1 motor 0
arm_joint_2 -> Board1 motor 1
arm_joint_3 -> Board1 motor 2
base_joint  -> Board1 motor 3
```

Board2는 `arm_joint_4` 하나이며 motor ID는 0이다.

## 3. CAN Move V2 계약

Board1 Move CAN ID는 `0x101`, Board2 Move CAN ID는 `0x102`, DLC는 항상 8이다.

```text
Byte0    flags | local_motor_id
Byte1~4 int32 absolute target, little-endian
Byte5    uint8 trajectory_id
Byte6    uint8 point_seq
Byte7    uint8 duration_5ms
```

Byte0:

```text
bit7 0x80 Execute: 반드시 1
bit6 0x40 Relative: 반드시 0; V2 펌웨어는 relative를 거절함
bit5 0x20 Step Mode: 일반 서버 경로에서는 0
bit4 0x10 Protocol V2: 반드시 1
bit3~0 local motor ID
```

일반 절대각 명령은 `byte0 = 0x90 | motor_id`다. Board1은 `0x90,0x91,0x92,0x93`, Board2는 `0x90`이다. 기존 bit4=0 command를 보내지 마라. Byte5~6은 더 이상 speed가 아니다. 기존 코드가 Byte5~6에 uint16 speed를 pack하면 프로토콜이 깨진다.

target 단위는 `0.01도`다. radian 입력은 다음 의미로 가장 가까운 정수에 변환한다.

```text
target_raw = nearest_integer(position_rad * 180 / pi * 100)
```

언어 기본 `round()`가 bankers rounding이면 그대로 사용하지 말고 기존 프로젝트의 각도 helper 또는 명시적인 half-away-from-zero/동등한 규칙을 사용한다. int32 signed little-endian 표준 packing을 사용한다.

펌웨어 실제 제한:

| 축 | 최소 | 최대 |
|---|---:|---:|
| Board1 motor0 / arm_joint_1 | -85.00° | 90.00° |
| Board1 motor1 / arm_joint_2 | -78.10° | 80.00° |
| Board1 motor2 / arm_joint_3 | -91.50° | 90.00° |
| Board1 motor3 / base_joint | -90.00° | 180.00° |
| Board2 motor0 / arm_joint_4 | -90.00° | 90.00° |

범위를 벗어나면 clamp하지 말고 goal 생성을 실패시키며 joint name, radian 값, 변환 raw 값과 허용 범위를 로그로 남긴다.

## 4. trajectory ID와 point sequence

- Board1과 Board2에 같은 `trajectory_id`와 같은 `point_seq`를 사용한다.
- 서버 시작 시 또는 새로운 goal마다 uint8 trajectory ID를 할당한다.
- 직전에 CANCEL한 trajectory ID는 펌웨어가 tombstone 처리하여 늦은 frame을 거절한다. 새 goal은 반드시 다른 ID를 사용한다.
- point sequence는 첫 전송 point에서 0으로 시작하고 point마다 1씩 증가시킨다. uint8 modulo 256 wrap을 허용한다.
- Board1은 서로 섞여 도착한 최대 8개의 미완성 point를 `(trajectory_id, point_seq)`별 slot에서 조립한다.
- Board1은 각 point의 네 motor frame이 어떤 순서로 와도 수신하지만, 서버는 계속 `0→1→2→3`으로 보낸다.
- Board1은 완성 순서와 무관하게 point sequence 순서로만 실행 큐에 넣는다.
- Board2는 한 frame이 한 point이며 미래 sequence를 reorder 저장하지 않는다. 반드시 정확한 point sequence 순서로 송신한다.

하나의 Board1 point 네 frame 사이에 다른 point, 다른 Board1 move, START/CANCEL을 끼워 넣지 마라. 네 frame을 하나의 application-level atomic batch로 단일 송신 worker에서 직렬화한다. ROS callback 여러 개가 직접 CAN socket에 쓰면 안 된다.

## 5. duration 변환

Byte7은 밀리초가 아니라 5ms tick이다.

```text
유효값 1..255
실제 요청 범위 5..1275ms
duration_ms = duration_5ms * 5
```

MoveIt의 `time_from_start`는 누적 시각이므로 누적 시각을 먼저 5ms grid에 올림한 뒤 차분한다. 각 segment delta를 개별 반올림해 누적 오차를 만들지 마라.

```text
tick_i = ceil(time_from_start_i / 5ms)
duration_tick_i = tick_i - tick_(i-1)
```

- `time_from_start=0`인 첫 point가 현재 상태를 표현하면 baseline으로만 사용하고 CAN point로 보내지 않는다.
- t=0 point가 현재 위치와 다르면 0ms 이동을 만들지 말고 trajectory를 거절한다.
- `duration_tick_i == 0`이면 조용히 1로 바꾸거나 waypoint를 버리지 말고 trajectory를 거절하고 5ms 미만 샘플 간격임을 보고한다.
- `duration_tick_i > 255`이면 같은 MoveIt 선분 위에 중간점을 선형 보간해 각 조각을 255 tick 이하로 분할한다. 이는 원래 piecewise-linear joint path를 벗어나면 안 된다.
- Board1 네 frame과 Board2 한 frame은 같은 point sequence에서 동일한 duration tick을 사용한다.
- 움직이지 않는 축도 생략하지 않는다.

각 보드는 모든 축이 움직이지 않는 point도 duration 동안 dwell한 후 다음 point로 넘어가도록 구현돼 있다. 따라서 시간 보존을 위해 zero-delta point도 전송한다.

## 6. 완전한 joint point 만들기

모든 CAN point는 다섯 관절의 절대 목표를 가져야 한다.

- trajectory에 모든 joint가 있으면 joint name으로 값을 추출한다.
- 일부 joint만 있다면 최신 position-valid feedback을 baseline으로 하고, 첫 point부터 이름으로 제공된 joint만 갱신하며 이후 point는 직전 완성 point 값을 carry forward한다.
- homed/position-valid feedback이 없는 누락 joint를 임의로 0도로 만들지 마라. goal을 거절한다.
- Board1에서는 움직이지 않는 축까지 네 frame을 항상 보낸다.
- Board2에서도 arm_joint_4가 움직이지 않더라도 한 frame을 보낸다.

## 7. 예시 payload

다음 point를 가정한다.

```text
trajectory_id = 0x2A
point_seq      = 0x01
duration       = 20ms = 4 ticks
Board1 motor0  = 30.00°  -> 3000
Board1 motor1  = -15.50° -> -1550
Board1 motor2  = 0.00°   -> 0
Board1 motor3  = 90.00°  -> 9000
Board2 motor0  = 10.00°  -> 1000
```

정확한 frame:

```text
CAN 0x101: 90 B8 0B 00 00 2A 01 04
CAN 0x101: 91 F2 F9 FF FF 2A 01 04
CAN 0x101: 92 00 00 00 00 2A 01 04
CAN 0x101: 93 28 23 00 00 2A 01 04
CAN 0x102: 90 E8 03 00 00 2A 01 04
```

## 8. START/CANCEL 및 V2 capability handshake

공통 control CAN ID는 `0x040`, DLC 8이다.

```text
Byte0 1 = START, 2 = CANCEL
Byte1 trajectory_id
Byte2~7 반드시 0
```

서버 시작 또는 CAN 재연결 후 실제 Move를 보내기 전에 capability probe를 수행한다.

1. goal에 사용하지 않을 probe trajectory ID를 고른다.
2. `02 <probe_id> 00 00 00 00 00 00` CANCEL을 한 번 보낸다.
3. Board1 `0x401`과 Board2 `0x402`에서 protocol version 2, result COMMITTED, point_seq `0xFF` ACK를 모두 기다린다.
4. ACK가 없으면 old firmware 또는 통신 불일치로 판단하고 V2 Move를 절대 보내지 않는다.
5. probe ID는 tombstone되므로 실제 goal ID로 재사용하지 않는다.

preload 순서:

1. Board1과 Board2 point를 생성한다.
2. 양쪽에 `min(20, 전체 point 수)`를 preload한다.
3. 양쪽에서 해당 point들의 COMMITTED를 확인한다.
4. START `01 <trajectory_id> 00...00`을 한 번 broadcast한다.
5. Board1과 Board2 모두 point_seq `0xFF`, result COMMITTED ACK를 보낸 것을 확인한다.
6. 그 후에만 goal을 RUNNING으로 표시한다.

고정 7ms 또는 40ms timer로 point를 하나씩 보내지 마라. Queue Free credit에 따라 burst refill한다.

CANCEL 시:

1. 해당 goal generation을 invalid 처리해 신규 old-point enqueue를 즉시 막는다.
2. application 송신 큐에서 해당 trajectory의 아직 안 보낸 frame을 모두 제거한다.
3. 하나의 CAN writer만 사용해 이미 enqueue된 move 뒤에 CANCEL을 직렬화한다.
4. 가능하면 SocketCAN TX queue drain/송신 완료를 확인한다.
5. CANCEL을 전송하고 Board1/Board2 ACK를 모두 기다린다.
6. 다음 goal은 다른 trajectory ID를 사용한다.

START/CANCEL ACK는 ACK frame의 point_seq가 `0xFF`, mask가 0이다. ACK 자체에는 START와 CANCEL 구분 필드가 없으므로 서버의 현재 control request context로 대응시킨다.

## 9. ACK/NACK 계약

Board1 ACK ID는 `0x401`, Board2 ACK ID는 `0x402`, DLC는 8이다.

```text
Byte0 protocol_version = 2
Byte1 result
Byte2 trajectory_id
Byte3 point_seq
Byte4 received_axis_mask
Byte5 queue_free_points
Byte6 Board1 RX overflow saturated counter; Board2는 현재 0
Byte7 ACK sequence counter, uint8 wrap
```

Result:

```text
0 COMMITTED
1 BUFFERED_OUT_OF_ORDER
2 DUPLICATE
3 QUEUE_FULL
4 WINDOW_FULL
5 STAGING_TIMEOUT
6 GROUP_CONFLICT
7 INVALID
```

서버는 `(trajectory_id, point_seq, board)`별로 최소 다음 상태를 관리한다.

```text
UNSENT -> SENT -> BUFFERED 또는 COMMITTED
```

처리 규칙:

- COMMITTED: 해당 보드의 point 적재 완료.
- BUFFERED_OUT_OF_ORDER: Board1 네 축은 모두 수신됐지만 앞 sequence가 비어 있음. 재전송하지 말고 이후 COMMITTED를 기다린다.
- DUPLICATE: Board1 mask가 `0x0F`, Board2 mask가 `0x01`이면 이미 수신/commit된 point 재확인으로 처리할 수 있다. Board1 partial mask duplicate는 point 완료가 아니므로 COMMITTED로 처리하지 않는다.
- QUEUE_FULL: 현재 모션은 유지된다. 즉시 반복 송신하지 말고 Queue Free가 생길 때까지 기다린다.
- WINDOW_FULL: Board1은 next commit sequence로부터 8개 이상 앞선 point, Board2는 기대 sequence가 아닌 미래 point다. 누락된 앞 point부터 해결한다.
- STAGING_TIMEOUT: Board1에서 첫 축 수신 후 100ms 넘게 네 축이 완성되지 않음. 로그에 mask를 남기고 해당 point 네 frame 전체를 같은 ID/sequence로 재전송한다.
- GROUP_CONFLICT: 같은 group 내부 duration/target 충돌, 다른 active trajectory ID, tombstoned ID 등이 포함된다. 무한 재시도하지 말고 송신 직렬화와 ID를 검사한다. 순수 partial group 충돌이면 네 frame 전체를 다시 보낸다.
- INVALID: DLC, flags, motor, duration 0, relative mode, target range 등 생성 오류다. 동일 payload 무한 재시도 금지.

Board1은 partial axis frame마다 ACK하지 않는다. 네 축 완성, duplicate, conflict, timeout 등의 이벤트에서 ACK한다. 네 frame 중 첫 frame ACK를 기다리는 동기 송신 구조를 만들지 마라.

ACK sequence gap은 진단 로그에 남기되 단독으로 모션 실패를 만들지 않는다. trajectory ID와 point sequence로 실제 상태를 판단한다.

ACK 유실 복구 기본값은 다음으로 고정한다.

- point group 송신 후 250ms 동안 ACK가 없고 status heartbeat는 정상이라면 같은 group 전체를 재전송한다.
- Board1은 네 frame 전체, Board2는 한 frame 전체를 같은 trajectory ID/point sequence로 재전송한다.
- 최대 3회까지만 재시도하고 이후 goal을 통신 실패로 종료한다.
- BUFFERED_OUT_OF_ORDER를 받은 point에는 이 ACK timeout 재전송을 적용하지 않는다. 선행 point를 먼저 복구한다.
- QUEUE_FULL/WINDOW_FULL은 250ms blind retry 대상이 아니다. Queue Free 또는 선행 sequence 상태 변화를 기다린다.
- 재전송으로 DUPLICATE full mask를 받으면 COMMITTED ACK 유실 복구로 처리한다.

## 10. Queue Free: 가장 중요한 단위 변경

Queue Free는 이제 CAN frame 수가 아니라 완성된 trajectory point 수다.

```text
Board1 최대 Queue Free = 32 point
Board2 최대 Queue Free = 32 point
```

절대 다음처럼 처리하지 마라.

```text
구버전 Board1 Queue Free 31 * 4 = 124 frame credit
Queue Free를 축 수로 나누기
Queue Free 124를 124 point로 해석하기
```

Board1 point 하나는 CAN frame 네 개지만 Queue Free credit은 정확히 1개다. Board1은 첫 축 frame으로 staging slot을 만들 때 실행 큐 한 칸을 예약하므로 partial point도 Queue Free를 1 감소시킨다.

Status와 ACK의 Queue Free는 같은 point 단위다.

- Board1 Status `0x201` Byte5
- Board2 Status `0x202` Byte5
- Board1 ACK `0x401` Byte5
- Board2 ACK `0x402` Byte5

서버에 다음 protocol mismatch guard를 반드시 넣는다.

```text
if board1_queue_free > 32: fatal protocol mismatch; 송신 중단
if board2_queue_free > 32: fatal protocol mismatch; 송신 중단
```

Board1에서 124가 보이면 구 firmware의 frame-credit 의미이거나 구 parser다. 현재 V2의 정상 최대값은 32다. clamp하거나 계속 진행하지 말고 명확히 “firmware/server Queue Free unit mismatch”를 기록한다.

서버는 point를 송신 예약하는 순간 로컬 credit을 1 차감하고, ACK/Status의 최신 Queue Free로 보정한다. 한 Board1 point의 네 frame마다 4 차감하면 안 된다.

refill 기본값:

- START 전 초기 preload 목표 20 point
- START 후 양쪽 Queue Free가 10 이상일 때 최대 10 point burst
- 실제 burst 수는 `min(Board1 free, Board2 free, remaining, 10)`
- 한쪽 보드만 먼저 refill해 sequence가 크게 벌어지지 않게 동일 point 단위로 양쪽에 공급
- Queue Free와 COMMITTED ACK 없이 queue capacity를 추측해 무제한 송신하지 않음

## 11. Status 및 완료 판정

Board1 Status `0x201`, Board2 Status `0x202`, DLC 8:

```text
Byte0 state
Byte1 fatal/reported error
Byte2 axis0 low nibble, axis1 high nibble
Byte3 axis2 low nibble, axis3 high nibble
Byte4 limit bits
Byte5 queue_free_points
Byte6 enabled (0 또는 1)
Byte7 status sequence
```

축 nibble:

```text
bit0 homed/position valid
bit1 ready
bit2 moving
bit3 target reached
```

State:

```text
0 INIT
1 IDLE
2 HOMING
3 MOVING
4 ERROR
5 ESTOP
6 DISABLED
```

Error:

```text
0 NONE
1 INVALID_CMD
2 LIMIT_SWITCH_DETECTED
3 DRIVER_FAULT
4 HOMING_FAIL
5 QUEUE_FULL (구/비-V2 경로 호환; V2 flow-control Queue Full은 ACK NACK로 처리)
```

goal 완료는 duration timer만으로 판정하지 않는다. 다음을 모두 확인한다.

- Board1 state IDLE, 네 축 moving=0, 네 축 target reached=1, Queue Free=32
- Board2 state IDLE, axis0 moving=0, target reached=1, Queue Free=32
- 양쪽 error=0
- 해당 trajectory의 모든 point가 양쪽 COMMITTED
- 대기 중인 동일 goal 송신 frame이 없음

활성 point는 실행 큐에서 pop되므로 이동 중에도 Queue Free가 최대값일 수 있다. Queue Free만으로 완료 처리하지 마라. 반대로 중간 waypoint에서 target reached가 순간적으로 보일 수 있으므로 state IDLE 조건을 반드시 함께 사용한다.

펌웨어는 최대속도 1000 step/s, 가속도 500 step/s²를 우선하며 요청 duration보다 실제 이동을 연장할 수 있다. `duration + 짧은 grace`로 취소하지 마라. `arm_task_server_node.py` 상위 timeout도 같은 원칙으로 수정한다.

- 기존 CAN/status heartbeat watchdog은 유지한다.
- 0x201 또는 0x202가 1초 이상 오지 않으면 통신 오류로 구분한다.
- 정상 MOVING heartbeat가 계속 오고 error가 없으면 duration 초과만으로 실패시키지 않는다.
- 사용자/상위 시스템의 별도 장기 watchdog이 필요하면 정상 MOVING과 통신 단절을 구분하고 충분히 큰 정책값을 설정한다.

## 12. Position feedback 역매핑

Board1 Position `0x301`, DLC 8:

```text
Byte0~1 motor0 int16 LE, 0.01° -> arm_joint_1/global1
Byte2~3 motor1 int16 LE, 0.01° -> arm_joint_2/global2
Byte4~5 motor2 int16 LE, 0.01° -> arm_joint_3/global3
Byte6~7 motor3 int16 LE, 0.01° -> base_joint/global0
```

Board2 Position `0x302`, DLC 8:

```text
Byte0~1 motor0 int16 LE, 0.01° -> arm_joint_4/global4
Byte2~7 reserved 0
```

CAN 슬롯 순서를 global joint 순서로 복사하지 말고 명시적 역매핑을 사용한다.

## 13. 기존 서버의 숨은 영향까지 반드시 수정

다음 항목을 실제 저장소에서 확인하고 함께 수정한다.

- `arm_task_server_node.py`의 duration+grace 상위 취소: status 기반 완료로 변경하지 않으면 bridge만 고쳐도 상위에서 실패함.
- `send_test_trajectory`: current→target→current를 한 goal의 마지막 point만 사용하는 구 구현 흔적이 있으면 제거한다. 이번 V2는 모든 waypoint를 보내므로 원래 path 의미를 유지하되, 테스트가 V2 START/ACK/완료를 기다리도록 갱신한다.
- `roscue_arm_pick` validator: 구 duration tick/queue capacity/124 frame-credit 값을 강제하는 검증을 제거하고 V2의 5ms tick, Board1/Board2 각 32 point로 변경한다.
- 공용 `pack_position_command()`: Board3가 사용한다면 수정하지 말고 `pack_board1_v2_point()`와 `pack_board2_v2_point()` 같은 전용 API로 분리한다.
- 상태 모델/진단 UI/로그에서 Queue Free 단위를 `frames`가 아니라 `points`로 이름까지 변경한다.
- 기존에 32→127/124 변경을 가정한 상수, threshold, 나눗셈/곱셈을 저장소 전체에서 검색해 제거한다.
- Board1/Board2 command Byte5~6을 speed로 읽거나 쓰는 코드를 전부 제거한다. Board3의 speed 필드는 그대로 둔다.
- SocketCAN 송신을 timer callback 여러 개가 직접 호출한다면 단일 writer queue로 통합한다.
- MoveIt이 만든 중간 waypoint를 버리거나 마지막 point만 보내지 않는다. 전체 path를 유지한다.

## 14. 필수 자동 테스트

1. Board1 한 point가 정확히 4 frame, Board2가 1 frame 생성되는지
2. 여러 MoveIt waypoint가 모두 보존되는지
3. joint name→Board/local motor mapping 및 Board1 0→1→2→3 순서
4. 음수 int32 little-endian packing
5. Byte5 trajectory ID, Byte6 point sequence, Byte7 duration tick 위치
6. Byte5~6에 구 speed가 들어가지 않는지
7. duration 1 tick과 255 tick
8. duration 0, 5ms 미만 quantized segment 처리
9. 1275ms 초과 segment 선형 분할
10. cumulative ceil quantization으로 총 시간이 빨라지지 않는지
11. 움직이지 않는 축도 모든 point에 포함되는지
12. Board1/Board2 동일 trajectory ID/point sequence/duration 사용
13. START가 preload COMMITTED 전에는 전송되지 않는지
14. capability probe에서 양쪽 V2 ACK가 없으면 Move를 막는지
15. ACK result 0~7 parser와 상태 전이
16. BUFFERED ACK 후 즉시 재전송하지 않는지
17. partial DUPLICATE를 COMMITTED로 오판하지 않는지
18. timeout/conflict 시 Board1 네 frame 전체 재전송
19. Board1/Board2 Queue Free 최대32 validation
20. Queue Free=124 수신 시 fatal protocol mismatch로 중단하는지
21. Board1 point 하나 송신 예약 시 credit 1만 감소하는지
22. Queue Full에서 busy retry loop를 만들지 않는지
23. CANCEL 전 application 송신 큐가 purge되는지
24. CANCEL 후 같은 trajectory ID를 재사용하지 않는지
25. state MOVING이면 duration 초과만으로 실패하지 않는지
26. state IDLE+target reached+queue max+all committed일 때만 완료되는지
27. 0x301/0x302 역매핑
28. Board3 기존 frame snapshot이 한 바이트도 변하지 않는지
29. virtual CAN에서 예시 payload와 START/CANCEL/ACK 흐름 통합 검증
30. 75 point/약1.25초 trajectory를 고정 40ms 송신 없이 preload/refill하는지

가능하면 vcan 테스트에서 frame 순서를 의도적으로 섞어 다음을 검증한다.

```text
point1 motor0,1,2
point2 motor0,1
point1 motor3
point2 motor2,3
```

Board1은 point1 COMMITTED 후 point2 COMMITTED가 되어야 한다. 서버 parser는 BUFFERED/COMMITTED를 올바르게 추적해야 한다.

## 15. 결과 보고 형식

작업 완료 후 반드시 다음을 보고한다.

1. 변경 파일과 목적
2. 실제 발견한 trajectory→CAN 데이터 흐름
3. 새 Board1/Board2 packer 함수 시그니처
4. single CAN writer와 atomic Board1 batch 구현 위치
5. trajectory ID/point sequence 할당 위치
6. duration cumulative quantization 위치
7. Queue Free point-credit 상태 머신
8. capability probe, preload, START, refill, CANCEL 흐름
9. duration+grace를 제거한 모든 상위 계층 위치
10. Board3가 변경되지 않았다는 snapshot/회귀 근거
11. 실행한 테스트 명령과 결과
12. 남은 실제 CAN 장비 시험 항목

구현 중 이 문서와 기존 서버 코드가 충돌하면 기존 코드를 임의로 보존하거나 절충하지 말고, 충돌 위치와 영향을 먼저 명확히 보고한 뒤 이 V2 wire contract에 맞춰 Board1/Board2 경로만 수정한다.
