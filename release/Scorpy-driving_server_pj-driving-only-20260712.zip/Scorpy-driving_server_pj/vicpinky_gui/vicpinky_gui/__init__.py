"""VicPinky browser GUI package."""
