"""VicPinky navigation adapter package."""
