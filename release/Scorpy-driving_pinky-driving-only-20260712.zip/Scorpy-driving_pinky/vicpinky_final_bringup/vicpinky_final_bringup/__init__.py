"""VicPinky final bringup package."""
