import json

from vicpinky_task_servers.base_drive_straight_server import (
    BaseDriveStraightServer,
    parse_drive_options,
)
from vicpinky_task_servers.base_rotate_server import BaseRotateServer


def test_drive_rejects_stale_odom(monkeypatch):
    server = object.__new__(BaseDriveStraightServer)
    server.latest_xy = (1.0, 2.0)
    server.last_odom_monotonic = 10.0
    server.odom_stale_timeout_sec = 0.5

    monkeypatch.setattr(
        'vicpinky_task_servers.base_drive_straight_server.time.monotonic',
        lambda: 10.6,
    )
    assert not server.odom_is_fresh()


def test_drive_accepts_fresh_odom(monkeypatch):
    server = object.__new__(BaseDriveStraightServer)
    server.latest_xy = (1.0, 2.0)
    server.last_odom_monotonic = 10.0
    server.odom_stale_timeout_sec = 0.5

    monkeypatch.setattr(
        'vicpinky_task_servers.base_drive_straight_server.time.monotonic',
        lambda: 10.4,
    )
    assert server.odom_is_fresh()


def test_drive_options_accept_driving_only_start_delay():
    options = parse_drive_options(
        json.dumps({
            'distance_m': 0.27,
            'speed_mps': 0.15,
            'start_delay_sec': 2.0,
        }),
        default_speed=0.10,
    )

    assert options == (0.27, 0.15, 2.0)


def test_drive_options_clamp_negative_start_delay():
    options = parse_drive_options(
        json.dumps({'start_delay_sec': -1.0}),
        default_speed=0.15,
    )

    assert options == (0.60, 0.15, 0.0)


def test_rotation_rejects_stale_odom(monkeypatch):
    server = object.__new__(BaseRotateServer)
    server.latest_yaw = 0.25
    server.last_odom_monotonic = 20.0
    server.odom_stale_timeout_sec = 0.5

    monkeypatch.setattr(
        'vicpinky_task_servers.base_rotate_server.time.monotonic',
        lambda: 20.6,
    )
    assert not server.odom_is_fresh()


def test_rotation_requires_an_odom_sample(monkeypatch):
    server = object.__new__(BaseRotateServer)
    server.latest_yaw = None
    server.last_odom_monotonic = 0.0
    server.odom_stale_timeout_sec = 0.5

    monkeypatch.setattr(
        'vicpinky_task_servers.base_rotate_server.time.monotonic',
        lambda: 0.1,
    )
    assert not server.odom_is_fresh()
